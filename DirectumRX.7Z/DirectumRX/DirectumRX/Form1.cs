﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace DirectumRX
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        string connectionString = "Server=localhost;Database=тест;Uid=root;pwd=root;";

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "Задача 2.Департамент, в котором у сотрудника зарплата максимальна";
            label1.Visible = true;

            string query = "SELECT departmen.name, employee.salary FROM departmen JOIN employee ON employee.departmen_id = departmen.id_departmen AND employee.salary = (SELECT max(salary) FROM employee)";
            dataGridView3.Rows.Clear();
            dataGridView3.Visible = true;
            dataGridView4.Visible = false;
            dataGridView1.Visible = false;
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();



            while (reader.Read())
            {

                dataGridView3.Rows.Add(reader["name"], reader["salary"]);
            }

            reader.Close();
            connection.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            label1.Text = "Задача 3.Зарплаты руководителей департаментов по убыванию";
            label1.Visible = true;

            string query = "SELECT *FROM cheif ORDER BY salary DESC";
            dataGridView4.Rows.Clear();
            dataGridView3.Visible = false;
            dataGridView1.Visible = false;            
            dataGridView4.Visible = true;
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();



            while (reader.Read())
            {

                dataGridView4.Rows.Add(reader["id_cheif"], reader["name"], reader["salary"]);
            }

            reader.Close();
            connection.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "SELECT departmen.name, (SELECT sum(employee.salary) FROM employee WHERE employee.departmen_id = departmen.id_departmen) AS summ FROM departmen";
           
            label1.Text = "Задача 1.1.Суммарная зарплата в разрезе департаментов без руководителем";
            label1.Visible = true;

            dataGridView1.Rows.Clear();
            dataGridView3.Visible = false;
            dataGridView4.Visible = false;            
            dataGridView1.Visible = true;
            MySqlConnection connection = new MySqlConnection(connectionString);
            connection.Open();
            MySqlCommand command = new MySqlCommand(query, connection);
            MySqlDataReader reader = command.ExecuteReader();



            while (reader.Read())
            {

                dataGridView1.Rows.Add(reader["name"],reader["summ"]);
            }

            reader.Close();
            connection.Close();
        }

        
    }
}
